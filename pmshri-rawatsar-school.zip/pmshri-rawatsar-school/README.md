# PM SHRI Govt. Sr. Sec. School, Rawatsar – Official Website & Portal

Modern, glassmorphism-themed school management system for **पीएम श्री राजकीय उच्च माध्यमिक विद्यालय, रावतसर** (Hanumangarh, Rajasthan).

## Features

- **Public Landing Page** – School info, principal message (Shri Satyadev Rathore), schemes (Poshan Ahaar, PM SHRI, Smart Classrooms…), streams (Science / Commerce / Arts), Nur–12.
- **Parent Dashboard** – Login via mobile/email → linked student cards with photo placeholder, overall score ring (red/orange/green), attendance %, class teacher, recent scores, download result.
- **Public Student Search** – Search by SR No. or Name (published data only; sensitive contacts hidden).
- **News / Circulars** – Holidays, events, achievements.
- **Staff Portal** – Student management, result entry, news publishing, OCR-ready result-sheet upload flow.
- **Admin Panel** – Full control, audit logs, user roles, site settings.
- **Security** – JWT httpOnly cookies, bcrypt passwords, role-based access, audit logging.
- **Theme** – Dark smoke + orange (classic PM SHRI / Rajasthan) glassmorphism.
- **Central Config** – `config.ts` holds domain, credentials placeholders, contact, principal, schemes – edit once.

## Quick Start (VPS + Cloudflare Tunnel)

```bash
# On your Meowlix VPS
git clone <this-repo>  # or upload the zip
cd pmshri-rawatsar-school
chmod +x install.sh
./install.sh
```

The installer installs Node 20, dependencies, creates SQLite DB, seeds demo data, builds, and starts with PM2.

### Cloudflare Tunnel (no public IP)

```bash
# Install cloudflared
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o cloudflared
chmod +x cloudflared
sudo mv cloudflared /usr/local/bin/

cloudflared tunnel login
cloudflared tunnel create pmshri-rawatsar
# Follow DNS instructions
cloudflared tunnel run --url http://localhost:3000 pmshri-rawatsar
```

## Demo Credentials

| Role   | Identifier                          | Password            |
|--------|-------------------------------------|---------------------|
| Admin  | admin@pmshri-rawatsar.local         | Admin@Rawatsar2026  |
| Staff  | staff@pmshri-rawatsar.local         | Staff@Rawatsar2026  |
| Parent | 7777777777                          | Parent@123          |

**Change all passwords immediately.**

## Project Structure

```
config.ts                 ← SINGLE source for domain, contacts, principal, colors
prisma/schema.prisma      ← Full data model (User, Student, Result, News, AuditLog…)
prisma/seed.ts            ← Demo students, exams, news, users
src/app/                  ← Next.js App Router pages
src/components/           ← Navbar, Footer, ScoreRing (glass UI)
src/lib/                  ← auth, db, utils
install.sh                ← One-command VPS setup
```

## Next Steps You Can Add

1. Wire Tesseract.js / Google Vision for result-sheet photo → automatic marks extraction.
2. Bulk CSV student import (600+ students).
3. Real attendance module linked to biometric / teacher marking.
4. PDF result download (jsPDF or Puppeteer).
5. Switch SQLite → PostgreSQL for production scale.
6. Replace placeholder principal photo with actual image from Facebook.
7. Add more staff CRUD pages (already scaffolded).

## Tech Stack

- Next.js 14 (App Router)
- Prisma + SQLite (easy single-VPS)
- Tailwind CSS + Framer Motion ready
- JWT + bcrypt
- PM2 + Cloudflare Tunnel ready

Built for the school community of Rawatsar under PM SHRI & NEP 2020.

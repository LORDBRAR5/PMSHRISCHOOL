/**
 * CENTRAL CONFIGURATION FILE
 * Edit this file only for domain, credentials, contact details, links etc.
 * All repeated values live here so you never hardcode them elsewhere.
 */

export const SITE = {
  name: "PM SHRI Govt. Sr. Sec. School, Rawatsar",
  nameHi: "पीएम श्री राजकीय उच्च माध्यमिक विद्यालय, रावतसर",
  shortName: "PMSHRI Rawatsar",
  tagline: "Excellence • Equity • Innovation under NEP 2020",
  established: 1950,
  udise: "08020415702",
  address: "Ward No. 16, Rawatsar, Hanumangarh, Rajasthan – 335524",
  district: "Hanumangarh",
  state: "Rajasthan",
  pin: "335524",
  classes: "Nursery / Class 1 to Class 12",
  streams: ["Science", "Commerce", "Arts"],
  medium: ["Hindi", "English"],
  studentCountApprox: "600+",
  facebook: "https://www.facebook.com/p/%E0%A4%AA%E0%A5%80%E0%A4%8F%E0%A4%AE-%E0%A4%B6%E0%A5%8D%E0%A4%B0%E0%A5%80-%E0%A4%B0%E0%A4%BE%E0%A4%9C%E0%A4%95%E0%A5%80%E0%A4%AF-%E0%A4%89%E0%A4%9A%E0%A5%8D%E0%A4%9A-%E0%A4%AE%E0%A4%BE%E0%A4%A7%E0%A5%8D%E0%A4%AF%E0%A4%AE%E0%A4%BF%E0%A4%95-%E0%A4%B5%E0%A4%BF%E0%A4%A6%E0%A5%8D%E0%A4%AF%E0%A4%BE%E0%A4%B2%E0%A4%AF-%E0%A4%B0%E0%A4%BE%E0%A4%B5%E0%A4%A4%E0%A4%B8%E0%A4%B0-100063882289098/",
  twitter: "https://x.com/GsssRawats999",
  email: "pmshri.rawatsar@rajasthan.gov.in", // placeholder – update
  phone: "+91-XXXXX-XXXXX", // update with real number
  principal: {
    name: "Shri Satyadev Rathore",
    nameHi: "श्री सत्यदेव राठौड़",
    designation: "Principal / प्रधानाचार्य",
    message: "Our mission is the holistic development of every student so they can contribute to nation-building. Under PM SHRI we are building modern facilities, smart classrooms and quality education for all.",
  },
  schemes: [
    "PM SHRI (PM Schools for Rising India)",
    "Poshan Ahaar / Mid-Day Meal",
    "Samagra Shiksha Abhiyan",
    "Smart Classrooms & Digital Boards",
    "NEET / JEE / CUET oriented coaching support",
    "Library & Computer Lab upgrades via CSR & Bhamashahs",
  ],
  colors: {
    primary: "#EA580C",      // orange-600 classic PM SHRI / Rajasthan govt feel
    primaryDark: "#C2410C",
    accent: "#F97316",
    white: "#FFFFFF",
    glass: "rgba(255, 255, 255, 0.08)",
    glassBorder: "rgba(255, 255, 255, 0.18)",
  },
} as const;

export const AUTH = {
  jwtSecret: process.env.JWT_SECRET || "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_IN_PRODUCTION_pmshri_rawatsar_2026",
  jwtExpiresIn: "7d",
  cookieName: "pmshri_session",
  roles: ["PARENT", "STAFF", "ADMIN"] as const,
};

export const DB = {
  // SQLite for easy single-VPS deploy. Switch to PostgreSQL URL when ready.
  url: process.env.DATABASE_URL || "file:./data/school.db",
};

export const FEATURES = {
  ocrResultUpload: true,          // staff can upload photo of result sheet
  publicStudentSearch: true,      // anyone can search by SR No / Name (limited data)
  attendanceModule: true,         // placeholder ready
  auditLogs: true,
  parentDownloadResult: true,
  glassmorphismTheme: true,
};

export const DOMAIN = {
  // Update after Cloudflare Tunnel / domain setup
  production: process.env.NEXT_PUBLIC_SITE_URL || "https://pmshri-rawatsar.yourdomain.com",
  local: "http://localhost:3000",
};

#!/usr/bin/env bash
set -euo pipefail

echo "=============================================="
echo "  PM SHRI Rawatsar School – Auto Installer"
echo "=============================================="

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[+]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }

# 1. System packages
log "Updating system & installing dependencies..."
if command -v apt-get &>/dev/null; then
  sudo apt-get update -y
  sudo apt-get install -y curl git build-essential python3
elif command -v yum &>/dev/null; then
  sudo yum install -y curl git gcc-c++ make python3
fi

# 2. Node.js 20 via nvm or nodesource
if ! command -v node &>/dev/null || [[ $(node -v | cut -d. -f1 | tr -d v) -lt 18 ]]; then
  log "Installing Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs || true
fi

log "Node: $(node -v)  npm: $(npm -v)"

# 3. Project setup
cd "$(dirname "$0")"
log "Installing npm packages..."
npm install

# 4. Environment
if [ ! -f .env ]; then
  log "Creating .env from example..."
  cp .env.example .env
  # Generate random JWT secret
  SECRET=$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | xxd -p)
  sed -i "s|generate-a-long-random-string-here-min-32-chars|$SECRET|" .env || true
fi

# 5. Database
mkdir -p data
log "Generating Prisma client & pushing schema..."
npx prisma generate
npx prisma db push

log "Seeding demo data..."
npx tsx prisma/seed.ts || npm run db:seed || true

# 6. Build
log "Building production Next.js app..."
npm run build

# 7. PM2 (optional process manager)
if ! command -v pm2 &>/dev/null; then
  log "Installing PM2 globally..."
  sudo npm install -g pm2
fi

log "Starting with PM2..."
pm2 delete pmshri-rawatsar 2>/dev/null || true
pm2 start npm --name "pmshri-rawatsar" -- start
pm2 save
pm2 startup || true

echo ""
echo "=============================================="
echo "  Installation complete!"
echo "=============================================="
echo ""
echo "  Local URL : http://localhost:3000"
echo ""
echo "  Demo logins:"
echo "    Admin  → admin@pmshri-rawatsar.local  / Admin@Rawatsar2026"
echo "    Staff  → staff@pmshri-rawatsar.local   / Staff@Rawatsar2026"
echo "    Parent → 7777777777                   / Parent@123"
echo ""
echo "  Cloudflare Tunnel (no public IP needed):"
echo "    1. Install cloudflared"
echo "    2. cloudflared tunnel login"
echo "    3. cloudflared tunnel create pmshri-rawatsar"
echo "    4. cloudflared tunnel route dns <tunnel-id> your.domain.com"
echo "    5. cloudflared tunnel run --url http://localhost:3000 <tunnel-name>"
echo ""
echo "  Edit config.ts for school name, principal, contact, colors etc."
echo "  Change all default passwords immediately after first login."
echo "=============================================="

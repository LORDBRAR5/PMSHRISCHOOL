import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding PM SHRI Rawatsar database...");

  const adminHash = await bcrypt.hash("Admin@Rawatsar2026", 12);
  const staffHash = await bcrypt.hash("Staff@Rawatsar2026", 12);
  const parentHash = await bcrypt.hash("Parent@123", 12);

  const admin = await prisma.user.upsert({
    where: { email: "admin@pmshri-rawatsar.local" },
    update: {},
    create: {
      email: "admin@pmshri-rawatsar.local",
      mobile: "9999999999",
      passwordHash: adminHash,
      name: "System Administrator",
      role: "ADMIN",
    },
  });

  const staffUser = await prisma.user.upsert({
    where: { email: "staff@pmshri-rawatsar.local" },
    update: {},
    create: {
      email: "staff@pmshri-rawatsar.local",
      mobile: "8888888888",
      passwordHash: staffHash,
      name: "Shri Teacher Example",
      role: "STAFF",
      staffProfile: {
        create: {
          designation: "Senior Teacher",
          subjects: JSON.stringify(["Mathematics", "Physics"]),
          isClassTeacher: true,
          classAssigned: "12",
          section: "A",
        },
      },
    },
  });

  // Sample students
  const studentsData = [
    { srNo: "SR2024001", name: "Aarav Sharma", fatherName: "Rajesh Sharma", class: "12", section: "A", stream: "Science", attendancePct: 92 },
    { srNo: "SR2024002", name: "Priya Rathore", fatherName: "Satyadev Rathore", class: "11", section: "B", stream: "Commerce", attendancePct: 88 },
    { srNo: "SR2024003", name: "Rohan Meena", fatherName: "Suresh Meena", class: "10", section: "A", stream: null, attendancePct: 76 },
    { srNo: "SR2024004", name: "Ananya Singh", fatherName: "Vikram Singh", class: "9", section: "C", stream: null, attendancePct: 95 },
    { srNo: "SR2024005", name: "Karan Beniwal", fatherName: "Mahendra Beniwal", class: "12", section: "A", stream: "Arts", attendancePct: 81 },
  ];

  for (const s of studentsData) {
    await prisma.student.upsert({
      where: { srNo: s.srNo },
      update: {},
      create: {
        ...s,
        gender: "Male",
        classTeacher: "Shri Teacher Example",
        admissionYear: 2020,
      },
    });
  }

  // Parent linked to first student
  const parent = await prisma.user.upsert({
    where: { mobile: "7777777777" },
    update: {},
    create: {
      mobile: "7777777777",
      email: "parent@example.com",
      passwordHash: parentHash,
      name: "Rajesh Sharma",
      role: "PARENT",
    },
  });

  const student1 = await prisma.student.findUnique({ where: { srNo: "SR2024001" } });
  if (student1) {
    await prisma.parentStudent.upsert({
      where: { parentId_studentId: { parentId: parent.id, studentId: student1.id } },
      update: {},
      create: { parentId: parent.id, studentId: student1.id },
    });
  }

  // Sample exam + results
  const exam = await prisma.exam.upsert({
    where: { id: "seed-exam-1" },
    update: {},
    create: {
      id: "seed-exam-1",
      name: "Unit Test – July 2025",
      type: "Unit",
      academicYear: "2025-26",
      class: "12",
      published: true,
    },
  });

  if (student1) {
    const subjects = [
      { subject: "Physics", marks: 78, max: 100, teacher: "Shri Physics Sir" },
      { subject: "Chemistry", marks: 85, max: 100, teacher: "Smt. Chemistry Madam" },
      { subject: "Mathematics", marks: 92, max: 100, teacher: "Shri Teacher Example" },
      { subject: "English", marks: 71, max: 100, teacher: "Smt. English Teacher" },
      { subject: "Hindi", marks: 88, max: 100, teacher: "Shri Hindi Sir" },
    ];
    for (const sub of subjects) {
      await prisma.result.create({
        data: {
          studentId: student1.id,
          examId: exam.id,
          subject: sub.subject,
          marksObtained: sub.marks,
          maxMarks: sub.max,
          teacherName: sub.teacher,
          grade: sub.marks >= 90 ? "A+" : sub.marks >= 80 ? "A" : sub.marks >= 70 ? "B+" : "B",
        },
      });
    }
  }

  // News
  await prisma.news.createMany({
    data: [
      {
        title: "Admission Drive Success – 41 New Admissions in One Day",
        titleHi: "प्रवेश अभियान सफलता – एक दिन में 41 नए प्रवेश",
        content: "PM SHRI Govt. Sr. Sec. School Rawatsar recorded 41 new admissions in a single day. Principal Shri Satyadev Rathore thanked staff, alumni and Bhamashahs. Enrolment is expected to cross 800 this year.",
        category: "Achievement",
        published: true,
      },
      {
        title: "Smart Boards Installed with Bhamashah Support",
        titleHi: "भामाशाह सहयोग से स्मार्ट बोर्ड स्थापित",
        content: "Five classrooms now have smart boards enabling quality teaching and competitive exam preparation (NEET, JEE, CUET).",
        category: "Event",
        published: true,
      },
      {
        title: "Holiday Notice – Independence Day",
        titleHi: "अवकाश सूचना – स्वतंत्रता दिवस",
        content: "School will remain closed on 15 August. Flag hoisting and cultural programme will be held on 14 August at 8:00 AM. All students must attend in uniform.",
        category: "Holiday",
        published: true,
      },
    ],
  });

  console.log("Seed complete.");
  console.log("Admin login  → email: admin@pmshri-rawatsar.local  /  Admin@Rawatsar2026");
  console.log("Staff login  → email: staff@pmshri-rawatsar.local   /  Staff@Rawatsar2026");
  console.log("Parent login → mobile: 7777777777                 /  Parent@123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());

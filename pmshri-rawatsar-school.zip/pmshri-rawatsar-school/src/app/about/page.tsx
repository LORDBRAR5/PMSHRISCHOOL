import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { SITE } from "../../../config";

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <h1 className="text-3xl font-bold text-white">About the School</h1>
        <p className="mt-2 text-lg text-orange-200/90 font-[family-name:var(--font-noto)]">
          {SITE.nameHi}
        </p>

        <div className="mt-8 space-y-6 text-stone-300 leading-relaxed">
          <p>
            <strong className="text-white">{SITE.name}</strong> is a Government Senior Secondary School
            located in Rawatsar, Hanumangarh district, Rajasthan. Established in {SITE.established},
            it now operates as a <strong className="text-orange-300">PM SHRI</strong> (PM Schools for Rising India)
            school — an exemplar institution implementing the National Education Policy 2020.
          </p>
          <p>
            The school offers education from {SITE.classes} with streams in{" "}
            {SITE.streams.join(", ")}. Medium of instruction includes Hindi and English support.
            Current enrolment is approximately {SITE.studentCountApprox} students.
          </p>
          <h2 className="text-xl font-semibold text-white pt-4">Leadership</h2>
          <p>
            Principal: <strong className="text-orange-300">{SITE.principal.name}</strong> ({SITE.principal.nameHi}).
            Under his guidance the school has strengthened infrastructure through Bhamashah contributions,
            installed smart boards, and improved admission & learning outcomes.
          </p>
          <h2 className="text-xl font-semibold text-white pt-4">Key Schemes & Facilities</h2>
          <ul className="list-disc pl-5 space-y-1">
            {SITE.schemes.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ul>
          <h2 className="text-xl font-semibold text-white pt-4">Location & Identity</h2>
          <p>
            Address: {SITE.address}<br />
            UDISE Code: {SITE.udise}<br />
            District: {SITE.district}, {SITE.state}
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}

"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function AdminPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (!d.user || d.user.role !== "ADMIN") router.push("/login");
        else setUser(d.user);
      });
  }, [router]);

  if (!user) return <div className="p-20 text-center text-stone-400">Loading…</div>;

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <h1 className="text-2xl font-bold text-white">Admin Control Panel</h1>
        <p className="text-stone-400">Full system administration – {user.name}</p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            "Add / Import Students (CSV or bulk)",
            "Manage Staff Accounts & Roles",
            "Publish / Unpublish Results",
            "Site Settings (config.ts values)",
            "View Audit Logs (who did what)",
            "Backup Database",
            "News Moderation",
            "OCR Result Review Queue",
            "Security & Session Control",
          ].map((item) => (
            <div key={item} className="glass-card p-5">
              <h3 className="font-medium text-orange-300">{item}</h3>
              <p className="mt-2 text-xs text-stone-500">Ready for expansion – Prisma models already support these actions.</p>
            </div>
          ))}
        </div>

        <div className="mt-10 glass-card p-6">
          <h2 className="font-semibold text-white">Default Credentials (change immediately)</h2>
          <ul className="mt-3 space-y-1 text-sm text-stone-300">
            <li>Admin: admin@pmshri-rawatsar.local / Admin@Rawatsar2026</li>
            <li>Staff: staff@pmshri-rawatsar.local / Staff@Rawatsar2026</li>
            <li>Parent demo: 7777777777 / Parent@123</li>
          </ul>
        </div>
      </main>
      <Footer />
    </>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { verifyPassword, signToken, logAction } from "@/lib/auth";
import { AUTH } from "../../../../../config";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { identifier, password } = body;
    if (!identifier || !password) {
      return NextResponse.json({ error: "Missing credentials" }, { status: 400 });
    }

    const user = await prisma.user.findFirst({
      where: {
        OR: [{ email: identifier }, { mobile: identifier }],
        isActive: true,
      },
    });

    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      return NextResponse.json({ error: "Invalid mobile/email or password" }, { status: 401 });
    }

    const token = signToken({
      userId: user.id,
      role: user.role,
      name: user.name,
    });

    await logAction(user.id, "LOGIN", "User", user.id);

    const res = NextResponse.json({
      user: { id: user.id, name: user.name, role: user.role, email: user.email, mobile: user.mobile },
    });

    res.cookies.set(AUTH.cookieName, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
      path: "/",
    });

    return res;
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

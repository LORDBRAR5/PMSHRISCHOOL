import { NextResponse } from "next/server";
import { AUTH } from "../../../../../config";

export async function POST() {
  const res = NextResponse.json({ ok: true });
  res.cookies.set(AUTH.cookieName, "", { maxAge: 0, path: "/" });
  return res;
}

import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET() {
  const session = await getSession();
  if (!session || session.role !== "PARENT") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const links = await prisma.parentStudent.findMany({
    where: { parentId: session.userId },
    include: {
      student: {
        include: {
          results: {
            include: { exam: true },
            orderBy: { createdAt: "desc" },
            take: 20,
          },
        },
      },
    },
  });

  const students = links.map((l) => {
    const s = l.student;
    const results = s.results;
    let totalObt = 0;
    let totalMax = 0;
    results.forEach((r) => {
      totalObt += r.marksObtained;
      totalMax += r.maxMarks;
    });
    const overallPct = totalMax > 0 ? (totalObt / totalMax) * 100 : 0;

    return {
      id: s.id,
      srNo: s.srNo,
      name: s.name,
      fatherName: s.fatherName,
      class: s.class,
      section: s.section,
      stream: s.stream,
      attendancePct: s.attendancePct,
      classTeacher: s.classTeacher,
      photoUrl: s.photoUrl,
      overallPct,
      recentResults: results.map((r) => ({
        subject: r.subject,
        marksObtained: r.marksObtained,
        maxMarks: r.maxMarks,
        examName: r.exam.name,
        teacherName: r.teacherName,
      })),
    };
  });

  return NextResponse.json({ students });
}

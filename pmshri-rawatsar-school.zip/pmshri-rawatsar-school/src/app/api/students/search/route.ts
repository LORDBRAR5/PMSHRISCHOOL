import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q")?.trim();
  if (!q || q.length < 2) {
    return NextResponse.json({ students: [] });
  }

  const students = await prisma.student.findMany({
    where: {
      isActive: true,
      OR: [
        { srNo: { contains: q } },
        { name: { contains: q } },
      ],
    },
    take: 20,
    include: {
      results: {
        include: { exam: true },
        where: { exam: { published: true } },
      },
    },
  });

  const mapped = students.map((s) => {
    let totalObt = 0;
    let totalMax = 0;
    s.results.forEach((r) => {
      totalObt += r.marksObtained;
      totalMax += r.maxMarks;
    });
    return {
      id: s.id,
      srNo: s.srNo,
      name: s.name,
      fatherName: s.fatherName,
      class: s.class,
      section: s.section,
      stream: s.stream,
      attendancePct: s.attendancePct,
      classTeacher: s.classTeacher,
      overallPct: totalMax > 0 ? (totalObt / totalMax) * 100 : 0,
    };
  });

  return NextResponse.json({ students: mapped });
}

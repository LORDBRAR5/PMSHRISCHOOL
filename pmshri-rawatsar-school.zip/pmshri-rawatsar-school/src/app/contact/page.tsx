import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { SITE } from "../../../config";
import { MapPin, Phone, Mail, Facebook, Twitter } from "lucide-react";

export default function ContactPage() {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <h1 className="text-3xl font-bold text-white">Contact Us</h1>
        <p className="mt-2 text-stone-400">Reach PM SHRI Govt. Sr. Sec. School, Rawatsar</p>

        <div className="mt-10 space-y-5">
          <div className="glass-card flex gap-4 p-5">
            <MapPin className="h-6 w-6 flex-shrink-0 text-orange-400" />
            <div>
              <h3 className="font-medium text-white">Address</h3>
              <p className="mt-1 text-stone-300">{SITE.address}</p>
            </div>
          </div>
          <div className="glass-card flex gap-4 p-5">
            <Phone className="h-6 w-6 flex-shrink-0 text-orange-400" />
            <div>
              <h3 className="font-medium text-white">Phone</h3>
              <p className="mt-1 text-stone-300">{SITE.phone} (update in config.ts)</p>
            </div>
          </div>
          <div className="glass-card flex gap-4 p-5">
            <Mail className="h-6 w-6 flex-shrink-0 text-orange-400" />
            <div>
              <h3 className="font-medium text-white">Email</h3>
              <p className="mt-1 text-stone-300">{SITE.email}</p>
            </div>
          </div>
          <div className="glass-card flex gap-4 p-5">
            <Facebook className="h-6 w-6 flex-shrink-0 text-orange-400" />
            <div>
              <h3 className="font-medium text-white">Facebook</h3>
              <a href={SITE.facebook} target="_blank" rel="noopener" className="mt-1 block text-orange-300 hover:underline">
                Official Facebook Page
              </a>
            </div>
          </div>
          <div className="glass-card flex gap-4 p-5">
            <Twitter className="h-6 w-6 flex-shrink-0 text-orange-400" />
            <div>
              <h3 className="font-medium text-white">X / Twitter</h3>
              <a href={SITE.twitter} target="_blank" rel="noopener" className="mt-1 block text-orange-300 hover:underline">
                @GsssRawats999
              </a>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}

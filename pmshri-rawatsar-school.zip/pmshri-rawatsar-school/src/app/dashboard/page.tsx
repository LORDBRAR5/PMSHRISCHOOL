"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ScoreRing from "@/components/ScoreRing";
import { formatDate } from "@/lib/utils";
import toast from "react-hot-toast";

type StudentCard = {
  id: string;
  srNo: string;
  name: string;
  fatherName: string;
  class: string;
  section: string | null;
  stream: string | null;
  attendancePct: number;
  classTeacher: string | null;
  photoUrl: string | null;
  overallPct: number;
  recentResults: { subject: string; marksObtained: number; maxMarks: number; examName: string }[];
};

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [students, setStudents] = useState<StudentCard[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const me = await fetch("/api/auth/me").then((r) => r.json());
      if (!me.user || me.user.role !== "PARENT") {
        router.push("/login");
        return;
      }
      setUser(me.user);
      const res = await fetch("/api/students/parent");
      if (res.ok) {
        const data = await res.json();
        setStudents(data.students || []);
      }
      setLoading(false);
    }
    load();
  }, [router]);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
  }

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="flex min-h-[50vh] items-center justify-center text-stone-400">Loading dashboard…</div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white">Parent Dashboard</h1>
            <p className="text-stone-400">Welcome, {user?.name}</p>
          </div>
          <button onClick={logout} className="btn-ghost text-sm">
            Logout
          </button>
        </div>

        {students.length === 0 ? (
          <div className="glass-card mt-10 p-10 text-center text-stone-400">
            No linked students found. Contact school office to link your account.
          </div>
        ) : (
          <div className="mt-10 grid gap-6 lg:grid-cols-2">
            {students.map((s) => (
              <div key={s.id} className="glass-card overflow-hidden p-6">
                <div className="flex gap-5">
                  <ScoreRing percentage={s.overallPct} size={100} />
                  <div className="flex-1">
                    <div className="flex items-start gap-3">
                      <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-orange-500/20 text-lg font-bold text-orange-300">
                        {s.name.charAt(0)}
                      </div>
                      <div>
                        <h2 className="text-lg font-semibold text-white">{s.name}</h2>
                        <p className="text-sm text-stone-400">
                          SR: {s.srNo} • Class {s.class}
                          {s.section ? `-${s.section}` : ""}
                          {s.stream ? ` • ${s.stream}` : ""}
                        </p>
                        <p className="text-xs text-stone-500">Father: {s.fatherName}</p>
                      </div>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-3 text-sm">
                      <span className="rounded-lg bg-white/5 px-2.5 py-1 text-stone-300">
                        Attendance: <strong className="text-orange-300">{s.attendancePct}%</strong>
                      </span>
                      {s.classTeacher && (
                        <span className="rounded-lg bg-white/5 px-2.5 py-1 text-stone-300">
                          Class Teacher: {s.classTeacher}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-5 border-t border-white/10 pt-4">
                  <h3 className="text-sm font-medium text-stone-300">Recent Scores</h3>
                  <ul className="mt-2 space-y-1.5">
                    {s.recentResults.slice(0, 4).map((r, i) => (
                      <li key={i} className="flex justify-between text-sm">
                        <span className="text-stone-400">{r.subject}</span>
                        <span className="font-medium text-white">
                          {r.marksObtained}/{r.maxMarks}
                        </span>
                      </li>
                    ))}
                    {s.recentResults.length === 0 && (
                      <li className="text-sm text-stone-500">No results published yet</li>
                    )}
                  </ul>
                </div>

                <div className="mt-5 flex gap-3">
                  <Link
                    href={`/dashboard/student/${s.id}`}
                    className="btn-primary flex-1 text-center text-sm"
                  >
                    View Full Details
                  </Link>
                  <button
                    className="btn-ghost text-sm"
                    onClick={() => toast.success("Result PDF download will be available after staff publishes")}
                  >
                    Download
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}

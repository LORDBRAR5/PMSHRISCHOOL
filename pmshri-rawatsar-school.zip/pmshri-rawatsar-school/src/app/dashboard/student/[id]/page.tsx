"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ScoreRing from "@/components/ScoreRing";

export default function StudentDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    fetch("/api/auth/me").then((r) => r.json()).then((d) => {
      if (!d.user) router.push("/login");
    });
    fetch("/api/students/parent")
      .then((r) => r.json())
      .then((d) => {
        const s = (d.students || []).find((x: any) => x.id === id);
        setData(s || null);
      });
  }, [id, router]);

  if (!data) {
    return (
      <>
        <Navbar />
        <div className="p-20 text-center text-stone-400">Loading student details…</div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
        <Link href="/dashboard" className="text-sm text-orange-400 hover:underline">← Back to Dashboard</Link>
        <div className="mt-6 glass-card p-6 sm:p-8">
          <div className="flex flex-wrap items-start gap-6">
            <ScoreRing percentage={data.overallPct} size={120} />
            <div>
              <h1 className="text-2xl font-bold text-white">{data.name}</h1>
              <p className="text-stone-400">SR: {data.srNo} • Class {data.class}{data.section ? `-${data.section}` : ""}</p>
              <p className="text-sm text-stone-500">Father: {data.fatherName}</p>
              <p className="mt-2 text-sm">Attendance: <strong className="text-orange-300">{data.attendancePct}%</strong></p>
              <p className="text-sm">Class Teacher: {data.classTeacher || "—"}</p>
            </div>
          </div>

          <h2 className="mt-8 text-lg font-semibold text-white">All Published Scores</h2>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-white/10 text-stone-400">
                  <th className="pb-2 pr-4">Subject</th>
                  <th className="pb-2 pr-4">Marks</th>
                  <th className="pb-2 pr-4">Exam</th>
                  <th className="pb-2">Teacher</th>
                </tr>
              </thead>
              <tbody>
                {data.recentResults.map((r: any, i: number) => (
                  <tr key={i} className="border-b border-white/5">
                    <td className="py-2.5 pr-4 text-white">{r.subject}</td>
                    <td className="py-2.5 pr-4 font-medium text-orange-300">{r.marksObtained}/{r.maxMarks}</td>
                    <td className="py-2.5 pr-4 text-stone-400">{r.examName}</td>
                    <td className="py-2.5 text-stone-400">{r.teacherName || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}

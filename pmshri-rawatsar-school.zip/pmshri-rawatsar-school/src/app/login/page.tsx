"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import toast from "react-hot-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { SITE } from "../../../config";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"parent" | "staff">("parent");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier, password, expectedRole: mode === "parent" ? "PARENT" : undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      toast.success(`Welcome, ${data.user.name}`);
      if (data.user.role === "ADMIN") router.push("/admin");
      else if (data.user.role === "STAFF") router.push("/staff");
      else router.push("/dashboard");
    } catch (err: any) {
      toast.error(err.message || "Invalid credentials");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="flex min-h-[70vh] items-center justify-center px-4 py-16">
        <div className="glass-card w-full max-w-md p-8">
          <h1 className="text-2xl font-bold text-white">Secure Login</h1>
          <p className="mt-1 text-sm text-stone-400">{SITE.shortName}</p>

          <div className="mt-6 flex rounded-xl bg-white/5 p-1">
            <button
              type="button"
              onClick={() => setMode("parent")}
              className={`flex-1 rounded-lg py-2 text-sm font-medium transition ${
                mode === "parent" ? "bg-orange-500 text-white" : "text-stone-400"
              }`}
            >
              Parent
            </button>
            <button
              type="button"
              onClick={() => setMode("staff")}
              className={`flex-1 rounded-lg py-2 text-sm font-medium transition ${
                mode === "staff" ? "bg-orange-500 text-white" : "text-stone-400"
              }`}
            >
              Staff / Admin
            </button>
          </div>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="mb-1.5 block text-sm text-stone-400">
                {mode === "parent" ? "Mobile Number or Email" : "Email or Mobile"}
              </label>
              <input
                className="input-field"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder={mode === "parent" ? "7777777777" : "admin@pmshri-rawatsar.local"}
                required
              />
            </div>
            <div>
              <label className="mb-1.5 block text-sm text-stone-400">Password</label>
              <input
                type="password"
                className="input-field"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? "Signing in…" : "Sign In"}
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-stone-500">
            Demo Parent: 7777777777 / Parent@123<br />
            Demo Staff: staff@pmshri-rawatsar.local / Staff@Rawatsar2026<br />
            Demo Admin: admin@pmshri-rawatsar.local / Admin@Rawatsar2026
          </p>
          <p className="mt-4 text-center text-sm text-stone-400">
            <Link href="/" className="text-orange-400 hover:underline">← Back to Home</Link>
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}

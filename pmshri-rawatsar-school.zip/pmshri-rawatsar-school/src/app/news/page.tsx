import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { prisma } from "@/lib/db";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function NewsPage() {
  let news: any[] = [];
  try {
    news = await prisma.news.findMany({
      where: { published: true },
      orderBy: { createdAt: "desc" },
      take: 30,
    });
  } catch {
    news = [];
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <h1 className="text-3xl font-bold text-white">School News & Circulars</h1>
        <p className="mt-2 text-stone-400">Updates from PM SHRI Govt. Sr. Sec. School, Rawatsar</p>

        <div className="mt-10 space-y-5">
          {news.length === 0 ? (
            <div className="glass-card p-8 text-center text-stone-400">
              No news published yet. Staff can add announcements from the staff panel.
            </div>
          ) : (
            news.map((n) => (
              <article key={n.id} className="glass-card p-6">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-orange-500/20 px-2.5 py-0.5 text-xs font-medium text-orange-300">
                    {n.category}
                  </span>
                  <time className="text-xs text-stone-500">{formatDate(n.createdAt)}</time>
                </div>
                <h2 className="mt-3 text-xl font-semibold text-white">{n.title}</h2>
                {n.titleHi && (
                  <p className="mt-1 text-sm text-orange-200/70 font-[family-name:var(--font-noto)]">
                    {n.titleHi}
                  </p>
                )}
                <p className="mt-3 leading-relaxed text-stone-300 whitespace-pre-line">{n.content}</p>
              </article>
            ))
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}

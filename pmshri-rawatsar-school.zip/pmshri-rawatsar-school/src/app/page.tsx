import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { SITE } from "../../config";
import {
  BookOpen,
  Users,
  Award,
  Laptop,
  Utensils,
  Sparkles,
  ArrowRight,
  MapPin,
} from "lucide-react";

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden px-4 pb-20 pt-16 sm:px-6">
          <div className="pointer-events-none absolute inset-0 bg-hero-smoke" />
          <div className="relative mx-auto max-w-7xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-orange-500/30 bg-orange-500/10 px-4 py-1.5 text-xs font-medium text-orange-300">
              <Sparkles className="h-3.5 w-3.5" />
              PM SHRI • Exemplar School under NEP 2020
            </div>
            <h1 className="mt-6 max-w-4xl text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
              {SITE.name}
            </h1>
            <p className="mt-3 text-xl text-orange-200/90 sm:text-2xl font-[family-name:var(--font-noto)]">
              {SITE.nameHi}
            </p>
            <p className="mt-5 max-w-2xl text-lg text-stone-300">
              {SITE.tagline}. From {SITE.classes} with all streams –{" "}
              {SITE.streams.join(", ")}. Quality education, modern facilities &
              government schemes for every child.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/login" className="btn-primary">
                Parent / Staff Login <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/search" className="btn-ghost">
                Search Student Result
              </Link>
              <Link href="/about" className="btn-ghost">
                About School
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap items-center gap-6 text-sm text-stone-400">
              <span className="flex items-center gap-1.5">
                <MapPin className="h-4 w-4 text-orange-400" />
                {SITE.address}
              </span>
              <span>UDISE: {SITE.udise}</span>
              <span>Est. {SITE.established}</span>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="px-4 py-12 sm:px-6">
          <div className="mx-auto grid max-w-7xl gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Users, label: "Students", value: SITE.studentCountApprox },
              { icon: BookOpen, label: "Classes", value: "Nur. – 12th" },
              { icon: Award, label: "Streams", value: "Sci / Comm / Arts" },
              { icon: Laptop, label: "Smart Classrooms", value: "Growing" },
            ].map((s) => (
              <div key={s.label} className="glass-card flex items-center gap-4 p-5">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
                  <s.icon className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{s.value}</p>
                  <p className="text-sm text-stone-400">{s.label}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Principal */}
        <section className="px-4 py-16 sm:px-6">
          <div className="mx-auto max-w-7xl">
            <h2 className="text-2xl font-bold text-white sm:text-3xl">Message from the Principal</h2>
            <div className="mt-8 glass-card overflow-hidden p-6 sm:p-8 md:flex md:gap-8">
              <div className="flex-shrink-0">
                <div className="mx-auto flex h-40 w-40 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-600/40 to-orange-900/40 text-5xl font-bold text-orange-200 md:mx-0">
                  SR
                </div>
                <p className="mt-3 text-center text-sm text-stone-400 md:text-left">
                  Photo from Facebook / School
                </p>
              </div>
              <div className="mt-6 md:mt-0">
                <h3 className="text-xl font-semibold text-orange-300">
                  {SITE.principal.name}
                </h3>
                <p className="text-sm text-stone-400 font-[family-name:var(--font-noto)]">
                  {SITE.principal.nameHi} • {SITE.principal.designation}
                </p>
                <p className="mt-4 leading-relaxed text-stone-300">
                  “{SITE.principal.message}”
                </p>
                <p className="mt-4 text-sm text-stone-500">
                  Under his leadership the school has seen strong admission growth,
                  smart-board installations via Bhamashah support, and continuous
                  focus on competitive exam readiness.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Features / Schemes */}
        <section className="px-4 py-16 sm:px-6">
          <div className="mx-auto max-w-7xl">
            <h2 className="text-2xl font-bold text-white sm:text-3xl">
              Facilities & Government Schemes
            </h2>
            <p className="mt-2 text-stone-400">
              Benefiting every student through national & state programmes
            </p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {SITE.schemes.map((scheme) => (
                <div key={scheme} className="glass-card flex items-start gap-3 p-5">
                  <Utensils className="mt-0.5 h-5 w-5 flex-shrink-0 text-orange-400" />
                  <span className="text-stone-200">{scheme}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="px-4 py-16 sm:px-6">
          <div className="mx-auto max-w-4xl rounded-3xl border border-orange-500/20 bg-gradient-to-br from-orange-600/20 to-transparent p-8 text-center sm:p-12">
            <h2 className="text-2xl font-bold text-white sm:text-3xl">
              Parents – Check your child’s progress anytime
            </h2>
            <p className="mt-3 text-stone-300">
              Secure login with mobile / email. View scores, attendance %,
              download results. Sensitive contact details remain private.
            </p>
            <Link href="/login" className="btn-primary mt-6 inline-flex">
              Go to Parent Dashboard
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

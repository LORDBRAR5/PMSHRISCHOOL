"use client";

import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ScoreRing from "@/components/ScoreRing";

export default function SearchPage() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  async function search(e: React.FormEvent) {
    e.preventDefault();
    if (!q.trim()) return;
    setLoading(true);
    setSearched(true);
    try {
      const res = await fetch(`/api/students/search?q=${encodeURIComponent(q.trim())}`);
      const data = await res.json();
      setResults(data.students || []);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <h1 className="text-3xl font-bold text-white">Student Result Search</h1>
        <p className="mt-2 text-stone-400">
          Search by SR Number or Student Name. Only published academic data is shown.
          Contact details remain private.
        </p>

        <form onSubmit={search} className="mt-8 flex gap-3">
          <input
            className="input-field flex-1"
            placeholder="Enter SR No. or Name…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? "Searching…" : "Search"}
          </button>
        </form>

        {searched && (
          <div className="mt-10 space-y-4">
            {results.length === 0 ? (
              <div className="glass-card p-8 text-center text-stone-400">No matching students found.</div>
            ) : (
              results.map((s) => (
                <div key={s.id} className="glass-card flex flex-wrap items-center gap-6 p-5">
                  <ScoreRing percentage={s.overallPct || 0} size={80} />
                  <div className="flex-1">
                    <h2 className="text-lg font-semibold text-white">{s.name}</h2>
                    <p className="text-sm text-stone-400">
                      SR: {s.srNo} • Class {s.class}
                      {s.section ? `-${s.section}` : ""} • Father: {s.fatherName}
                    </p>
                    <p className="mt-1 text-xs text-stone-500">
                      Attendance: {s.attendancePct}% • Class Teacher: {s.classTeacher || "—"}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}

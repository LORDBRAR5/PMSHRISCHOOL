"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Link from "next/link";

export default function StaffPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (!d.user || (d.user.role !== "STAFF" && d.user.role !== "ADMIN")) {
          router.push("/login");
        } else setUser(d.user);
      });
  }, [router]);

  if (!user) return <div className="p-20 text-center text-stone-400">Loading…</div>;

  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <h1 className="text-2xl font-bold text-white">Staff Portal</h1>
        <p className="text-stone-400">Welcome, {user.name} ({user.role})</p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { title: "Manage Students", desc: "View / edit student records, photos, SR numbers", href: "#" },
            { title: "Upload / Edit Results", desc: "Enter marks or upload result sheet photo (OCR ready)", href: "#" },
            { title: "Publish News", desc: "Post holidays, circulars, achievements", href: "#" },
            { title: "Attendance", desc: "Update attendance % (module ready)", href: "#" },
            { title: "Class Teacher View", desc: "Your assigned class students", href: "#" },
            { title: "Audit Logs", desc: "See your recent actions", href: "#" },
          ].map((c) => (
            <div key={c.title} className="glass-card p-5 transition hover:border-orange-500/30">
              <h3 className="font-semibold text-orange-300">{c.title}</h3>
              <p className="mt-2 text-sm text-stone-400">{c.desc}</p>
              <p className="mt-3 text-xs text-stone-500">Expandable – full CRUD APIs can be added next</p>
            </div>
          ))}
        </div>

        <div className="mt-10 glass-card p-6">
          <h2 className="font-semibold text-white">Result Sheet OCR Flow (Designed)</h2>
          <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-stone-300">
            <li>Staff photographs the handwritten / printed result sheet (Name, Father, SR, Class on top).</li>
            <li>Upload image + select Class.</li>
            <li>System runs OCR (Tesseract / cloud) and matches students by SR / Name.</li>
            <li>Staff reviews extracted marks, edits if needed, then publishes or keeps private.</li>
            <li>Published results appear on Parent Dashboard & public Search.</li>
          </ol>
          <p className="mt-4 text-xs text-stone-500">
            OCR engine can be wired later (tesseract.js or Google Vision). Structure is ready.
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}

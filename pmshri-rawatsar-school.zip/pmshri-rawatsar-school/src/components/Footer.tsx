import Link from "next/link";
import { SITE } from "../../config";

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-white/10 bg-stone-950/80">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <h3 className="text-lg font-bold text-orange-400">{SITE.shortName}</h3>
            <p className="mt-2 text-sm text-stone-400">{SITE.nameHi}</p>
            <p className="mt-3 text-sm text-stone-500">{SITE.address}</p>
          </div>
          <div>
            <h4 className="font-semibold text-stone-200">Quick Links</h4>
            <ul className="mt-3 space-y-2 text-sm text-stone-400">
              <li><Link href="/about" className="hover:text-orange-300">About School</Link></li>
              <li><Link href="/news" className="hover:text-orange-300">News & Circulars</Link></li>
              <li><Link href="/search" className="hover:text-orange-300">Student Search</Link></li>
              <li><Link href="/login" className="hover:text-orange-300">Parent / Staff Login</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-stone-200">Connect</h4>
            <ul className="mt-3 space-y-2 text-sm text-stone-400">
              <li><a href={SITE.facebook} target="_blank" rel="noopener" className="hover:text-orange-300">Facebook Page</a></li>
              <li><a href={SITE.twitter} target="_blank" rel="noopener" className="hover:text-orange-300">X / Twitter</a></li>
              <li>UDISE: {SITE.udise}</li>
            </ul>
          </div>
        </div>
        <div className="mt-10 border-t border-white/5 pt-6 text-center text-xs text-stone-500">
          © {new Date().getFullYear()} {SITE.name}. Built for the school community under PM SHRI & NEP 2020.
        </div>
      </div>
    </footer>
  );
}

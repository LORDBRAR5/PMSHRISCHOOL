"use client";

import { overallScoreColor, scoreLabel } from "@/lib/utils";

export default function ScoreRing({ percentage, size = 96 }: { percentage: number; size?: number }) {
  const color = overallScoreColor(percentage);
  const strokeClass =
    color === "red" ? "score-ring-red" : color === "orange" ? "score-ring-orange" : "score-ring-green";
  const r = (size - 12) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (percentage / 100) * circ;

  return (
    <div className="relative flex flex-col items-center" style={{ width: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="8"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          className={strokeClass}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.8s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xl font-bold text-white">{Math.round(percentage)}%</span>
        <span className="text-[10px] uppercase tracking-wider text-stone-400">{scoreLabel(percentage)}</span>
      </div>
    </div>
  );
}

import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { AUTH } from "../../config";
import { prisma } from "./db";

export type JwtPayload = {
  userId: string;
  role: string;
  name: string;
};

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export function signToken(payload: JwtPayload) {
  return jwt.sign(payload, AUTH.jwtSecret, { expiresIn: AUTH.jwtExpiresIn });
}

export function verifyToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, AUTH.jwtSecret) as JwtPayload;
  } catch {
    return null;
  }
}

export async function getSession(): Promise<JwtPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(AUTH.cookieName)?.value;
  if (!token) return null;
  return verifyToken(token);
}

export async function requireRole(roles: string[]) {
  const session = await getSession();
  if (!session || !roles.includes(session.role)) {
    throw new Error("Unauthorized");
  }
  return session;
}

export async function logAction(
  userId: string | null,
  action: string,
  entity?: string,
  entityId?: string,
  details?: object
) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: userId || undefined,
        action,
        entity,
        entityId,
        details: details ? JSON.stringify(details) : undefined,
      },
    });
  } catch (e) {
    console.error("Audit log failed", e);
  }
}

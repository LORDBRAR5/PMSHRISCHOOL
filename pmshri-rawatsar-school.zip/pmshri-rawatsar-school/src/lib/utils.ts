import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function overallScoreColor(pct: number): "red" | "orange" | "green" {
  if (pct < 40) return "red";
  if (pct < 70) return "orange";
  return "green";
}

export function scoreLabel(pct: number): string {
  if (pct < 40) return "Needs Improvement";
  if (pct < 70) return "Average";
  if (pct < 85) return "Good";
  return "Excellent";
}

export function formatDate(d: Date | string | null | undefined) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}
